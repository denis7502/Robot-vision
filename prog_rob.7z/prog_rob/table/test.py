import cv2
import numpy as np

def table_print(img):

	CHAR = {1:'a',2:'b',3:'c',4:'d',5:'e',6:'f',7:'g',8:'h'}
	INTEG = {'a':0,'b':1,'c':2,'d':3,'e':4,'f':5,'g':6,'h':7,}
	KOORD = {}
		
	def serch_pos(img):
		#img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
		_,img = cv2.threshold(img,200,255,cv2.THRESH_BINARY_INV)
		cells = []
		kernel = cv2.getStructuringElement(shape=cv2.MORPH_RECT, ksize=(7,7))
		img = cv2.morphologyEx(img, cv2.MORPH_GRADIENT,kernel)
		#img = cv2.GaussianBlur(img,(3,3),1)
		contours, hierarchy = cv2.findContours( img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
		#img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
		for cnt in contours:
		            rect = cv2.minAreaRect(cnt) # пытаемся вписать прямоугольник
		            box = cv2.boxPoints(rect) # поиск четырех вершин прямоугольника
		            box = np.int0(box) # округление координат
		            center = (int(rect[0][0]),int(rect[0][1]))
		            area = int(rect[1][0]*rect[1][1])
		            if area >1_000_000 and area < 10_600_000:
		            	#print(area)
		            	#print(box)
		            	img[:,0:330] = 0
		            	img[:,1410:] = 0
		            	img[0:120] = 0
		            	img[1_120:] = 0
		contours, hierarchy = cv2.findContours( img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
		img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
		for cnt in contours:
		            rect = cv2.minAreaRect(cnt) # пытаемся вписать прямоугольник
		            box = cv2.boxPoints(rect) # поиск четырех вершин прямоугольника
		            box = np.int0(box) # округление координат
		            center = (int(rect[0][0]),int(rect[0][1]))
		            area = int(rect[1][0]*rect[1][1])
		            if area >10_000 and area < 22_000:
		            	xsr = (box[0][0]+box[2][0])//2
		            	ysr =  (box[0][1]+box[2][1])//2
		            	temp = [box[0][0],box[0][1],box[2][0],box[2][1],xsr,ysr]
		            	img = cv2.drawContours(img,[box],0,(0,255,255),5)
		            	cells.append(temp)

		for i in range(len(cells)):
			for j in range(i,len(cells)):
				if np.abs(cells[i][4]-cells[j][4])<50:
					cells[j][4] = cells[i][4]
				if np.abs(cells[i][5]-cells[j][5])<100:
					cells[j][5] = cells[i][5]
				
		return cells
		
	img = np.uint8(img)
	table = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	
	cells = serch_pos(table)
	#cv2.imwrite('cam_1.jpg', table)
	cells = sorted(cells,key=lambda point: (point[5],point[4]))
	cell = cells
	width = np.abs(cell[0][3]-cell[0][1])
	height = np.abs(cell[0][2]-cell[0][0])
	for i in range(8):
		temp = 0
		for j in range(8):
			koord = [cell[(i*8+(j))][0],cell[(i*8+(j))][2],cell[(i*8+(j))][1],cell[(i*8+(j))][3],cell[(i*8+(j))][4],cell[(i*8+(j))][5]]
			#img = cv2.putText(img, '%s%s'%(CHAR[i+1],j+1), (koord[4],koord[5]), cv2.FONT_HERSHEY_SIMPLEX,1, (0,0,255), 6, cv2.LINE_AA)
			KOORD.update({"%s%s"%(CHAR[i+1],j+1):koord})
	#cv2.imwrite('cam1.jpg', img)
	return(KOORD)



img = cv2.imread('table.bmp')
KOORD = table_print(img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
_,img = cv2.threshold(img,200,255,cv2.THRESH_BINARY_INV)



contours, hierarchy = cv2.findContours( img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
for cnt in contours:
	rect = cv2.minAreaRect(cnt) # пытаемся вписать прямоугольник
	box = cv2.boxPoints(rect) # поиск четырех вершин прямоугольника
	box = np.int0(box) # округление координат
	center = (int(rect[0][0]),int(rect[0][1]))
	area = int(rect[1][0]*rect[1][1])
	if area >450 and area < 1000:
		if (KOORD['a1'][0] < box[0][0] < KOORD['a1'][1] and box[0][1] < KOORD['a1'][3])  or (KOORD['a1'][2] < box[0][1] < KOORD['a1'][3] and box[0][0] < KOORD['a1'][1]):
			#print(box[:,0],box[:,1])
			#print(box[0][0])
			#img = cv2.drawContours(img,[box],0,(0,255,255),20)
			center_x = box[0][0]+box[2][0]
			center_y = box[0][1]+box[2][1]
			img = cv2.circle(img,(int(center_x/2),int(center_y/2)), 5,(0,0,255),3)
		elif (KOORD['a8'][0] < box[0][0] and KOORD['a8'][2] > box[0][1])  or (KOORD['a8'][2] < box[0][1] < KOORD['a8'][3] ):
			#print(box[:,0],box[:,1])
			#print(box[0][0])
			#img = cv2.drawContours(img,[box],0,(0,255,255),20)
			center_x = box[0][0]+box[2][0]
			center_y = box[0][1]+box[2][1]
			img = cv2.circle(img,(int(center_x/2),int(center_y/2)), 10,(255,0,255),3)
		elif (KOORD['h8'][0] < box[0][0] < KOORD['h8'][1] )  or (KOORD['h8'][2] < box[0][1] < KOORD['h8'][3] and box[0][0] < KOORD['h8'][1] + 15 ):
			#print(box[:,0],box[:,1])
			#print(box[0][0])
			#img = cv2.drawContours(img,[box],0,(0,255,255),20)
			print(KOORD['h8'][:4])
			center_x = box[0][0]+box[2][0]
			center_y = box[0][1]+box[2][1]
			img = cv2.circle(img,(int(center_x/2),int(center_y/2)), 20,(80,11,255),3)
		#img = cv2.drawContours(img,[box],0,(0,0,255),5)	


cv2.imwrite('test.jpg',img)