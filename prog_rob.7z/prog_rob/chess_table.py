
class Table():

	import cv2
	import numpy as np
	import math
	import os
	import torch
	import pandas
	import pathlib

	def __init__(self):

		self.CHAR = {1:'a',2:'b',3:'c',4:'d',5:'e',6:'f',7:'g',8:'h'}
		self.INTEG = {'a':0,'b':1,'c':2,'d':3,'e':4,'f':5,'g':6,'h':7,}
		self.CENT_CHIPS = {}

	def chips_on_NN(self,img,model,BOARD,KOORD):

		import cv2
		import numpy as np

		INTEG = self.INTEG

		BOARD_copy = BOARD.copy()
		BOARD_copy[:][:] = 0
		image = img.copy()
		image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)


		results = model(image)
		results.save()

		pandas_table = results.pandas().xyxy[0]
		pandas_table['center_cell_x'] = (pandas_table.xmax + pandas_table.xmin)/2
		pandas_table['center_cell_y'] = (pandas_table.ymax + pandas_table.ymin)/2
		for x,y,h,w,name in zip(pandas_table['center_cell_x'].values,pandas_table['center_cell_y'].values,
									(pandas_table.xmax-pandas_table.xmin)/2, (pandas_table.ymax-pandas_table.ymin)/2, pandas_table['name'].values):
			for k,v in KOORD.items():
				cell = '%s'%(k)
				temp = v
				if abs(float(x)-temp[4]) < 65  and abs(float(y)-temp[5]) < 65:
					image = cv2.rectangle(image, (int(x-h), int(y-w)),(int(x+h), int(y+w)),(0,0,255),10)
					cv2.putText(image, '%s'%(str(k)), (int(x),int(y)), cv2.FONT_HERSHEY_SIMPLEX,1, (255,0,255), 5, cv2.LINE_AA)
					if str(name)[:5] == 'white':
						BOARD_copy[INTEG[cell[:1]]][int(cell[1:])-1] = 1
						break
					else:
						BOARD_copy[INTEG[cell[:1]]][int(cell[1:])-1] = -1
						break


		cv2.imwrite('test.jpg',image)
		
		return BOARD_copy

	def get_steps(self,board,New_board,TURN, white_black,stockfish):

		import numpy as np

		temp = []
		INTEG = self.INTEG
		for i in TURN:
			temp.append(i[:len(i)-1])
		stockfish.set_position(temp)
		char = {0:'a',1:'b',2:'c',3:'d',4:'e',5:'f',6:'g',7:'h'}
		if white_black == 'white':
			move = stockfish.get_best_move()
			if move == None:
				checkmate = True
				return checkmate
			p_1_str = move[:2]
			p_2_str = move[2:]
			p_1 = INTEG[move[:1]],int(move[1:2])-1
			p_2 = INTEG[move[2:3]],int(move[3:4])-1
			turn_str = '%s%s'%(p_1_str,p_2_str)
			turn = p_1,p_2

			return turn,turn_str
		else:
			temp = []
			for i in TURN:
				temp.append(i[:len(i)-1])
			stockfish.set_position(temp)


			move_matrix = New_board-board
			move = np.argwhere(move_matrix)
			for i in range(len(move)):
				for j in range(len(move)):
					p_1 = move[i][0],move[i][1]
					p_2 = move[j][0],move[j][1]
					p_1_str = '%s%s'%(char[move[i][0]],move[i][1]+1)
					p_2_str = '%s%s'%(char[move[j][0]],move[j][1]+1)
					if stockfish.is_move_correct('%s%s'%(p_1_str,p_2_str)):
						turn_str = '%s%s'%(p_1_str,p_2_str)
						turn = p_1,p_2
						return turn,turn_str
					elif stockfish.is_move_correct('%s%s'%(p_2_str,p_1_str)):
						turn_str = '%s%s'%(p_2_str,p_1_str)
						turn = p_2,p_1
						return turn,turn_str

	def get_img(self):
		    
		import time
		import urllib
		import urllib.request
		import cv2
		import numpy as np
		url_set = 'http://192.168.3.96/control?var=framesize&val=13'
		url = 'http://192.168.3.96/capture?inline?filename=capture.jpg'
		url_1=urllib.request.urlopen(url_set)
		cookie = url_1.headers.get('Set-Cookie')
		time.sleep(1)
		url_img = urllib.request.urlopen(url)
		url_img.headers.get('cookie', cookie)
		time.sleep(1)
		#print(len(bytearray(url_img.read())))
		imgNp=np.array(bytearray(url_img.read()),dtype=np.uint8)
		img=cv2.imdecode(imgNp,-1)
		
		return img
		
	def step(self,KOORD,model,stockfish):

		import numpy as np

		eat = False
		rock_long = False
		rock_lit = False
		INTEG = self.INTEG


		BOARD =self.np.array([[1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1],
						 [1,1,0,0,0,0,-1,-1]])
		try:
			with open('step.txt','r') as f:
				TURN = f.readline().split(',')
		except:
			with open('step.txt','w') as f:
				TURN = []
		TURN = TURN[:len(TURN)-1]
		if len(TURN)>0:
			temp = 0
			for i in TURN:
				if i[4:] == 'w':
					#pass
					BOARD[INTEG[str(i[:1])]][int(i[1:2])-1] = 0
					BOARD[INTEG[str(i[2:3])]][int(i[3:4])-1] = 1
				else:
					#pass
					BOARD[INTEG[str(i[:1])]][int(i[1:2])-1] = 0
					BOARD[INTEG[str(i[2:3])]][int(i[3:4])-1] = -1
		img_chip = self.get_img()
		New_board = self.chips_on_NN(img_chip,model,BOARD,KOORD)
		move_matrix = New_board - BOARD
		move = np.argwhere(move_matrix)
		print(New_board)
		turn_str = ''
		if len(move) == 0:
			turn,turn_str = self.get_steps(BOARD,New_board,TURN,'white',stockfish)
			turn_str += 'w'
			TURN.append(turn_str)
		elif len(move) >= 2 and len(move) <= 4:
			turn,turn_str = self.get_steps(BOARD,New_board,TURN,'black',stockfish)
			turn_str += 'b'
			TURN.append(turn_str)
			turn,turn_str = self.get_steps(BOARD,New_board,TURN,'white',stockfish)
			turn_str += 'w'
			TURN.append(turn_str)


		if turn_str == 'e1g1w' or turn_str == 'e8g8w':
			rock_lit = True
		elif turn_str == 'e1c1w' or turn_str == 'e8c8w':
			rock_long = True
		if 	New_board[turn[1][0]][turn[1][1]] == -1:
			eat = True
		k = len(TURN)
		BOARD = New_board	
		BOARD[turn[0][0]][turn[0][1]] = 0
		if k%2!=0:
			BOARD[turn[1][0]][turn[1][1]] = 1 
		else:
			BOARD[turn[1][0]][turn[1][1]] = -1
		f = open('data.txt','w+')
		temp = TURN[len(TURN)-1]
		f.write('%s %s'%(temp[:2],temp[2:4]))
		f.close()
		print(BOARD)
		print(TURN)
		f = open('step.txt','w+')
		for i in TURN:
			f.write('%s,'%(str(i)))
		f.close()

		print(eat,rock_long,rock_lit)
		
		return eat,rock_long,rock_lit

class Table_mini(Table):

	def __init__(self):
		pass

	def step(self,start, finish, white_black, BOARD):

		CHAR = {1:'a',2:'b',3:'c',4:'d',5:'e',6:'f',7:'g',8:'h'}
		INTEG = {'a':0,'b':1,'c':2,'d':3,'e':4,'f':5,'g':6,'h':7,}
		CENT_CHIPS = {}
		eat = False
		rock_long = False
		rock_lit = False
		try:
			if BOARD == None:
				BOARD = self.np.array([[1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1],
								 [1,1,0,0,0,0,-1,-1]])
		except:
			pass

		turn_str = start+finish+white_black
		start = INTEG['%s'%(start[0])], int(start[1])-1
		finish = INTEG['%s'%(finish[0])], int(finish[1])-1
		if BOARD[finish[0]][finish[1]] == 1 or BOARD[finish[0]][finish[1]] == -1:
			eat = True
		if white_black == 'w':
			BOARD[start[0]][start[1]] = 0
			BOARD[finish[0]][finish[1]] = 1
		elif white_black == 'b':
			BOARD[start[0]][start[1]] = 0
			BOARD[finish[0]][finish[1]] = -1
		if turn_str == 'e1g1w' or turn_str == 'e8g8w' or turn_str == 'e8g8b' or turn_str == 'e1g1b':
			rock_lit = True
		elif turn_str == 'e1c1w' or turn_str == 'e8c8w' or  turn_str == 'e1c1b' or turn_str == 'e8c8b':
			rock_long = True
		f = open('data.txt','w+')
		temp = turn_str[len(turn_str)-1]
		f.write('%s %s'%(temp[:2],temp[2:4]))
		f.close()
		if eat == True:
			pass
			#print(eat,rock_long,rock_lit)
		
		return eat,rock_long,rock_lit, BOARD


