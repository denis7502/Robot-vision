import keyboard
def get_img(k):

	import time
	import urllib
	import urllib.request
	import cv2
	import numpy as np
	url_set = 'http://192.168.3.96/control?var=framesize&val=13'
	url='http://192.168.3.96/capture?inline?filename=capture.jpg'

	url_1=urllib.request.urlopen(url_set)
	cookie = url_1.headers.get('Set-Cookie')
	time.sleep(1)
	url_img = urllib.request.urlopen(url)
	url_img.headers.get('cookie', cookie)
	time.sleep(1)
	#print(len(bytearray(url_img.read())))
	imgNp=np.array(bytearray(url_img.read()),dtype=np.uint8)
	img=cv2.imdecode(imgNp,-1)
	
	#return img
	cv2.imwrite('%s.bmp'%(k),img)

k=0
while True:
	if keyboard.is_pressed('P'):
		get_img(k)
		print(k)
		k+=1
		print('ready')
	if keyboard.is_pressed('Q'):
		break