def voice():
	try:
		import os
		import random as rm
		import time

		os.remove('speech.wav')
		fraze = ['хахахах', "добро пожаловать", "пока все", "ходи"]
		from yandex_speech import TTS
		tts = TTS("zahar", "wav", "b1g0miengilhsruc9rjf")
		k = rm.randint(0, len(fraze)-1)
		tts.generate("%s"%(fraze[k]))
		tts.save()




		import pyaudio  
		import wave

		chunk = 1024

		f = wave.open("speech.wav","rb")

		p = pyaudio.PyAudio()


		stream = p.open(format = p.get_format_from_width(f.getsampwidth()),  
		                channels = f.getnchannels(),  
		                rate = f.getframerate(),  
		                output = True)


		data = f.readframes(chunk)


		while data:  
		    stream.write(data)  
		    data = f.readframes(chunk)  

		#stop stream  
		stream.stop_stream()  
		stream.close()  

		#close PyAudio  
		p.terminate()  

	except:
		voice()


voice()